<template>
  <div class="vista-previa-container">
    <div class="vista-previa-aviso">
      <i class="bi bi-eye-fill"></i>
      Así se vería este registro publicado. Los cambios no se han guardado todavía.
    </div>

    <article class="preview-card">
      <header class="preview-hero" :class="{ 'sin-imagen': !imagenUrl }">
        <img v-if="imagenUrl" :src="imagenUrl" :alt="titulo || 'Imagen destacada'" class="preview-hero-image" />
        <div class="preview-hero-overlay" aria-hidden="true"></div>

        <div class="preview-hero-content">
          <h1 class="preview-titulo">{{ titulo || 'Sin título' }}</h1>

          <div class="preview-meta">
            <span class="version-badge">v{{ version || '0.0' }}</span>
            <span class="preview-fecha">{{ fechaTexto }}</span>
          </div>

          <div class="preview-tags">
            <span class="tag-gris">{{ areaNombre || 'Sin área' }}</span>
            <span v-for="cat in categorias" :key="cat" class="tag-gris">{{ cat }}</span>
            <span v-if="categorias.length === 0" class="tag-gris">Sin categorías</span>
          </div>
        </div>
      </header>

      <div class="preview-body">
        <section v-if="resumen" class="preview-resumen">
          <h2 class="preview-subtitulo">Resumen</h2>
          <p>{{ resumen }}</p>
        </section>

        <section class="preview-contenido">
          <div v-if="contenidoHtml" class="editorjs-editor" v-html="contenidoHtml"></div>
          <p v-else class="contenido-vacio">Todavía no hay contenido escrito en el editor.</p>
        </section>
      </div>
    </article>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  titulo?: string
  version?: string
  resumen?: string
  areaNombre?: string
  categorias?: string[]
  imagenUrl?: string | null
  fechaTexto?: string
  contenidoHtml?: string
}>(), {
  titulo: '',
  version: '',
  resumen: '',
  areaNombre: '',
  categorias: () => [],
  imagenUrl: null,
  fechaTexto: '',
  contenidoHtml: '',
})
</script>

<style scoped>
.vista-previa-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
}

.vista-previa-aviso {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  color: #075985;
  font-size: 0.82rem;
  font-weight: 600;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 10px;
  flex-shrink: 0;
}

.preview-card {
  overflow: hidden;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
}

.preview-hero {
  position: relative;
  display: flex;
  min-height: 200px;
  overflow: hidden;
  background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
}

.preview-hero-image,
.preview-hero-overlay {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}

.preview-hero-image {
  z-index: 1;
  object-fit: cover;
}

.preview-hero-overlay {
  z-index: 2;
  background: linear-gradient(to top, rgba(15, 23, 42, 0.9) 0%, rgba(15, 23, 42, 0.45) 45%, rgba(15, 23, 42, 0.05) 100%);
}

.preview-hero-content {
  position: relative;
  z-index: 3;
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: flex-end;
  gap: 10px;
  padding: 28px 24px 20px;
}

.preview-titulo {
  margin: 0;
  color: #ffffff;
  font-size: clamp(1.3rem, 2vw, 1.7rem);
  font-weight: 760;
  line-height: 1.2;
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.42);
}

.preview-meta {
  display: flex;
  align-items: center;
  gap: 14px;
}

.version-badge {
  padding: 4px 12px;
  color: #ffffff;
  font-family: 'Courier New', monospace;
  font-size: 0.78rem;
  font-weight: 700;
  background: rgba(255, 255, 255, 0.18);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 999px;
}

.preview-fecha {
  color: rgba(255, 255, 255, 0.92);
  font-size: 0.85rem;
  font-weight: 600;
  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.46);
}

.preview-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag-gris {
  padding: 4px 12px;
  color: #4a5568;
  font-size: 0.72rem;
  font-weight: 700;
  background: #f4f5f7;
  border-radius: 999px;
}

.preview-body {
  padding: 24px;
}

.preview-resumen {
  padding-bottom: 18px;
  margin-bottom: 18px;
  border-bottom: 1px solid #e2e8f0;
}

.preview-subtitulo {
  margin: 0 0 8px;
  color: #0f172a;
  font-size: 0.78rem;
  font-weight: 800;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

.preview-resumen p {
  margin: 0;
  color: #334155;
  font-size: 0.95rem;
  line-height: 1.7;
}

.contenido-vacio {
  padding: 8px 0;
  color: #94a3b8;
  font-size: 0.9rem;
  font-style: italic;
}

/* ─── Contenido de EditorJS, mismo estilo que la vista pública ─── */
.editorjs-editor {
  color: #334155;
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  font-size: 1rem;
  line-height: 1.75;
}

:deep(.editorjs-editor p) {
  margin-bottom: 1.1rem;
}

:deep(.editorjs-editor h1),
:deep(.editorjs-editor h2),
:deep(.editorjs-editor h3),
:deep(.editorjs-editor h4),
:deep(.editorjs-editor h5),
:deep(.editorjs-editor h6) {
  margin-top: 1.6rem;
  margin-bottom: 0.9rem;
  color: #0f172a;
}

:deep(.editorjs-editor ul),
:deep(.editorjs-editor ol) {
  margin-bottom: 1.1rem;
  padding-left: 1.8rem;
}

:deep(.editorjs-editor li) {
  margin-bottom: 0.4rem;
}

:deep(.editorjs-editor img) {
  display: block;
  max-width: 100%;
  height: auto;
  margin: 20px auto;
  border-radius: 12px;
}

:deep(.editorjs-editor blockquote) {
  padding-left: 18px;
  margin: 18px 0;
  color: #4a5568;
  font-style: italic;
  border-left: 4px solid var(--primary);
}

:deep(.editorjs-editor pre) {
  padding: 14px;
  margin: 18px 0;
  overflow-x: auto;
  color: #e2e8f0;
  background: #1e293b;
  border-radius: 12px;
}

:deep(.editorjs-editor code) {
  padding: 2px 6px;
  color: #d32f2f;
  font-size: 0.9em;
  background: #f1f5f9;
  border-radius: 6px;
}

@media (max-width: 480px) {
  .preview-hero-content {
    padding: 20px 16px 16px;
  }

  .preview-body {
    padding: 16px;
  }
}
</style>
